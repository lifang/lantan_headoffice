id;||;name;||;started_at;||;ended_at;||;introduction;||;disc_types;||;status;||;discount;||;store_id;||;disc_time_types;||;car_num;||;everycar_times;||;img_url;||;created_at;||;updated_at;||;is_subsidy;||;sub_content;||;code;||;description

|::|30;||;test_data;||;;||;;||;<p>

	ddsssdaadd

</p>

<p>

	ddd方法

</p>

<p>

	的得得得凤飞飞

</p>

<p>

	<br />

</p>

<p>

	fffff &nbsp; fsss方法风水师的

</p>

<p>

	凤飞飞撒额外

</p>

<p>

	的肉体和飞

</p>

<p>

	的的分分合合

</p>

<p>

	<br />

</p>;||;1;||;0;||;13.0;||;2;||;1;||;25;||;1;||;;||;2013-03-26 13:39:44 +0800;||;2013-03-26 13:39:44 +0800;||;0;||;;||;ZoWbkeMz;||;

|::|