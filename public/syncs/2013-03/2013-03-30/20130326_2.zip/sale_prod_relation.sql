id;||;sale_id;||;product_id;||;prod_num;||;created_at

|::|94;||;30;||;5;||;1;||;2013-03-26 13:39:44 +0800

|::|